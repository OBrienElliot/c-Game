﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Game
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("welcome to the game, match monsters coodinates with the players to squash the monster. monsters move ever second turn + The game ends when all monsters have been squashed");
            Console.WriteLine("press any button to proceed");
            

            //instanciate object from random class
            Random rnd = new Random();

            string Input;

            //while loop variable
            bool GamePlay = true;

            // create player object
            Player P1 = new Player("bob", 5, 5);

            //create monster opbjects within a List
            var monsters = new List<Monster>();

            for (int i = 0; i < 3; i++)
            {
                int rX = rnd.Next(11); //returns number between 0-10
                int rY = rnd.Next(11);

                // Intiazize the object and add it to the collection
                monsters.Add(new Monster(rX, rY));
            }
            
            //enter game loop until game end condition met
            while (GamePlay)
            {
               // Console.Clear();

                //display all monsters in list
                foreach (Monster mon in monsters)
                {
                    var MonMove = rnd.Next(4);
                    var mov = " ";

                    if (MonMove == 0)
                    { mov = "w"; }

                    if (MonMove == 1)
                    { mov = "a"; }

                    if (MonMove == 2)
                    { mov = "s"; }

                    if (MonMove == 3)
                    { mov = "d"; }

                    mon.Move(mov);
                    mon.Display();

                }

                checkColl(monsters, P1);


                //display player object
                P1.Display();

                Console.WriteLine("Move player: W, A, S, D");
                Console.WriteLine();

                //take movement off player
               Input = Console.ReadLine();

                if(Input==null)
                {
                    Input = Input.Substring(0, 1);
                }

                P1.Move(Input);

                Input = string.Empty;

                checkColl(monsters,P1);

            }
        }

        private static void checkColl(List<Monster> monsters, Player e)
        {
            for (int i = 0; i < monsters.Count(); i++)
            {
                if (monsters[i].posX == e.posX && monsters[i].posY == e.posY)
                {
                    monsters.Remove(monsters[i]);

                }

            }
        }
    }
}