﻿using System;

namespace Game
{
    sealed class Player : GamePiece
    {
        public string Name { get; set; }
        public int posY { get; set; }
        public int posX { get; set; }

        public Player(string name, int posx, int posy)
        {
            Name = name;
            posY = posy;
            posX = posx;

        }


        public override void Move(string INPUT)
        {

            switch (INPUT)
            {
                case "W":
                case "w":
                    posY++;

                    if (posY == 11)
                    {
                        posY = 10;
                    }
                    break;

                case "A":
                case "a":
                    posX--;

                    if (posX == -1)
                    {
                        posX = 0;
                    }
                    break;

                case "S":
                case "s":
                    posY--;

                    if (posY == -1)
                    {
                        posY = 0;
                    }
                    break;

                case "D":
                case "d":
                    posX++;

                    if (posX == 11)
                    {
                        posX = 10;
                    }
                    break;

                default:
                    Console.WriteLine("invalid move");
                    break;
            }
        }


        public override void Display()
        {
            Console.WriteLine("PLAYER'S pos is : " + posX + " , " + posY);
            Console.WriteLine();

        }
    }
}