﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game
{
    public abstract class GamePiece
    {
        public GamePiece()
        {
        }

        public abstract void Move(string INPUT);

        public abstract void Display();
    }
}