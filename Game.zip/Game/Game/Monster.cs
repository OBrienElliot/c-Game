﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game
{
    sealed class Monster : GamePiece
    {
        public int posY { get; set; }
        public int posX { get; set; }
        private bool everyOther = true;

        public Monster(int posy, int posx)
        {
            posY = posy;
            posX = posx;

        }

        //polymorphism
        public override void Move(string INPUT)
        {
            

            if (everyOther == true)
            {
                everyOther = false;

                switch (INPUT)
                {


                    case "w":
                        posY++;

                        if (posY == 11)
                        {
                            posY = 10;
                        }
                        break;

                    case "a":
                        posX--;

                        if (posX == -1)
                        {
                            posX = 0;
                        }
                        break;

                    case "s":
                        posY--;

                        if (posY == -1)
                        {
                            posY = 0;
                        }
                        break;

                    case "d":
                        posX++;

                        if (posX == 11)
                        {
                            posX = 10;
                        }
                        break;
                }
            }
            else
            {
                everyOther = true; 
            }
        }

 
        public override void Display()
        {
            Console.WriteLine("Monsters pos is: " + posX + " , " + posY);
            Console.WriteLine();

        }

    }
}

